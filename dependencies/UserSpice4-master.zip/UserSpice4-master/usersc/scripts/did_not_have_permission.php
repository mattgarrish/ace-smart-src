<?php
//Whatever happens in this script happens just before the user is officially redirected to account.php because they did not have proper permissions. You can either choose to redirect them somewhere else or perform some other logic.
//Redirect::to('https://facebook.com');
?>
